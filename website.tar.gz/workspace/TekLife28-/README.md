#Our company name is TekLife

![logo1](https://cloud.githubusercontent.com/assets/10826223/6214584/506d28da-b602-11e4-8e42-bce72275ebe3.png)

We are a company of 7 passionate software developers. We enjoy creating your software. Business dream and we make it come true.
TekLife Team

|Name              | ID         |

|-----------       |:----------:|

|Bergitte Saeed    |28-3808     | 

|Hussien Kamal     |28-1080     |

|Omar Ahmed        |28-1325     |

|Monica Gamal      |28-2288     |

|Jirayr Vahe       |19-0890     |

|Ahmed Naguib      |19-4073     |

|Mariam Afifi      |25-4119     |


