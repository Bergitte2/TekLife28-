class PagesController < ApplicationController
  def home
  end
  
  def profiles
  end
  
  def hussien
  end
  
  def nageeb
  end
  
  def omar
  end
  
  def monica
  end
  
  def bergitte
  end
  
  def jirayr
  end
  
  def mariam
  end
  
  def contact
  end
  
  def blog
  end
end
